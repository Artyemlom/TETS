dependency 'obituary'

description 'death messages using the obituary resource'

client_script 'client.lua'
server_script 'server.lua'