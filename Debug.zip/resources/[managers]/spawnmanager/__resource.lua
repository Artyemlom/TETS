client_script 'spawnmanager.lua'

export 'getRandomSpawnPoint'
export 'spawnPlayer'
export 'addSpawnPoint'
export 'loadSpawns'
export 'setAutoSpawn'
export 'forceRespawn'
